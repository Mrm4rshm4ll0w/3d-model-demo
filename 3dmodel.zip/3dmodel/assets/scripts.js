$(document).ready(function() {
    // Smooth scroll to core values section when clicking the connect button
    $('.connect-btn').on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({
            scrollTop: $('.core-values-section').offset().top
        }, 1000, 'easeInOutExpo');
    });
});